package com.readwriteinpropertiesfile.readwriteinpropertiesfile;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReadwriteinpropertiesfileApplicationTests {

	@Test
	void contextLoads() {
	}

}
