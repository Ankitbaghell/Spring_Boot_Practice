package com.readwriteinpropertiesfile.readwriteinpropertiesfile;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReadwriteinpropertiesfileApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReadwriteinpropertiesfileApplication.class, args);
	}

}
